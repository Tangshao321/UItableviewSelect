//
//  DefaultTableViewCell.m
//  test多选
//
//  Created by user on 2017/6/28.
//  Copyright © 2017年 TJX. All rights reserved.
//

#import "DefaultTableViewCell.h"

@implementation DefaultTableViewCell

- (void)layoutSubviews{
    [super layoutSubviews];
    
    
    
    [self.subviews enumerateObjectsUsingBlock:^(__kindof UIControl * _Nonnull control, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if ([control isMemberOfClass:NSClassFromString(@"UITableViewCellEditControl")]) {
            
            for (UIView *view in control.subviews) {
                
                if ([view isKindOfClass:[UIImageView class]]) {
                    
                    UIImageView *imageView = (UIImageView *)view;
                    if (self.selected) {
                        //设置选中时的照片
                        imageView.image = [UIImage imageNamed:@"选中"];
                    }else{
                        //设置未选中时的照片
//                        imageView.image = [UIImage imageNamed:@"未选中"];
                    }
                }
            }
        }
    }];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
