//
//  DefaultTableViewCell.h
//  test多选
//
//  Created by user on 2017/6/28.
//  Copyright © 2017年 TJX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultTableViewCell : UITableViewCell

@end
