//
//  ViewController.m
//  test多选
//
//  Created by user on 2017/6/28.
//  Copyright © 2017年 TJX. All rights reserved.
//

#import "ViewController.h"
#import "DefaultTableViewCell.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *tab;
@property (nonatomic,strong) NSMutableArray *muArray;
@property (nonatomic,strong) NSMutableArray *selectArray;
@property (nonatomic,assign) BOOL isAllSelected;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"编辑" style:UIBarButtonItemStylePlain target:self action:@selector(editClick:)];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"全选" style:UIBarButtonItemStylePlain target:self action:@selector(allSelectClick:)];
    
    self.muArray = [[NSMutableArray alloc] initWithArray:[UIFont familyNames]];
    
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _tab = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 50) style:UITableViewStylePlain];
    _tab.dataSource = self;
    _tab.delegate = self;
    _tab.rowHeight = 50.0f;
    // 允许编辑状态下多选
    _tab.allowsMultipleSelectionDuringEditing = YES;
    
    [self.view addSubview: _tab];
    
    
    
    UIView *bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height - 50, self.view.bounds.size.width, 50)];
    bottomView.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    delBtn.frame = CGRectMake(bottomView.bounds.size.width - 100, 0, 80, 50);
    [delBtn setTitle:@"删除" forState:UIControlStateNormal];
    [delBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [delBtn setBackgroundColor:[UIColor redColor]];
    [delBtn addTarget:self action:@selector(deleClick:) forControlEvents:UIControlEventTouchUpInside];
    [bottomView addSubview:delBtn];
    
    
    [self.view addSubview:bottomView];
    
    
}

- (void)deleClick:(UIButton *)button{
    
    UIAlertController *alert =[UIAlertController alertControllerWithTitle:@"提示" message:[NSString stringWithFormat:@"删除了 %ld 项数据",self.selectArray.count] preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
    [_tab setEditing:NO animated:YES];
    [self.muArray removeObjectsInArray:self.selectArray];
    [_tab reloadData];
    [self.selectArray removeAllObjects];
    
}

// 编辑
- (void)editClick:(UIBarButtonItem *)button{
    if ([button.title isEqualToString:@"编辑"]) {
        button.title = @"确定";
        [_tab setEditing:YES animated:YES];
    }
    else if ([button.title isEqualToString:@"确定"]){
        NSLog(@"%@",self.selectArray);
        button.title = @"编辑";
        [_tab setEditing:NO animated:YES];
        [self.selectArray removeAllObjects];
    }
    
    [self.selectArray removeAllObjects];
    
    for (NSInteger index = 0; index < self.muArray.count; index ++) {
        // 取消全选
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        if (_isAllSelected) {
            [self.selectArray addObject:[self.muArray objectAtIndex:indexPath.row]];
            [_tab selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
        else{
            [_tab deselectRowAtIndexPath:indexPath animated:NO];
        }
        
    }

    
}

// 全选
- (void)allSelectClick:(UIBarButtonItem *)button{
    
    if ([button.title isEqualToString:@"全选"]) {
        button.title = @"取消全选";
        [_tab setEditing:YES animated:YES];
        _isAllSelected = YES;
    }
    else if([button.title isEqualToString:@"取消全选"]){
        button.title = @"全选";
        _isAllSelected = NO;
    }
    
    
    [self.selectArray removeAllObjects];
    
    for (NSInteger index = 0; index < self.muArray.count; index ++) {
        // 取消全选
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        if (_isAllSelected) {
            [self.selectArray addObject:[self.muArray objectAtIndex:indexPath.row]];
            [_tab selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
        else{
            [_tab deselectRowAtIndexPath:indexPath animated:NO];
        }
        
    }
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.muArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DefaultTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[DefaultTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    // cell设置为可选择风格
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    // 设置选中颜色
//    UIView *backView = [[UIView alloc] init];
//    backView.backgroundColor = [UIColor colorWithRed:235 / 255.0 green:235 / 255.0 blue:235 / 255.0 alpha:1];
//    cell.selectedBackgroundView = backView;
    
    
    cell.textLabel.text = self.muArray[indexPath.row];
    
    return cell;
}

// 选中行
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.selectArray addObject:[self.muArray objectAtIndex:indexPath.row]];
}
// 取消行
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.selectArray removeObject:[self.muArray objectAtIndex:indexPath.row]];
}


- (NSMutableArray *)selectArray{
    if (!_selectArray) {
        _selectArray = [NSMutableArray array];
    }
    return _selectArray;
}

@end
